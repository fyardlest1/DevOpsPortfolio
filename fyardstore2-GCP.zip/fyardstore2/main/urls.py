# from urllib.parse import urlparse
from django.urls import path
from . import views

app_name = 'homepage'

urlpatterns = [
    path('', views.index, name='home')
]
